@main def inspect(cpgFile: String, output: String) = {
  importCpg(cpgFile)
  val matches = cpg.call.name("allow_frame").map { call =>
    ujson.Obj(
      "code" -> call.code,
      "line" -> call.lineNumber.getOrElse(-1),
      "caller" -> call.method.fullName,
      "callees" -> ujson.Arr.from(call.callee.fullName.l)
    )
  }.l
  val result = ujson.Obj(
    "nodeCount" -> cpg.all.size,
    "methods" -> ujson.Arr.from(cpg.method.fullName.l.sorted),
    "allowFrameCalls" -> ujson.Arr.from(matches)
  )
  os.write.over(os.Path(output), ujson.write(result, indent = 2))
}
