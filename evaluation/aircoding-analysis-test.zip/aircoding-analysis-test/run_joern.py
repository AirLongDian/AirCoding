"""Build two equivalent C++ fixtures, parse/export/query them, and compare evidence."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent


def unwrap(value):
    while isinstance(value, dict) and "@value" in value:
        value = value["@value"]
    if isinstance(value, list):
        return [unwrap(item) for item in value]
    return value


def inspect_graph(path):
    graph = json.loads(path.read_text(encoding="utf-8"))["@value"]
    matches = []
    for node in graph["vertices"]:
        if node["label"] != "CALL":
            continue
        props = {key: unwrap(value) for key, value in node["properties"].items()}
        props = {key: value[0] if isinstance(value, list) and len(value) == 1 else value for key, value in props.items()}
        if props.get("NAME") == "allow_frame":
            matches.append(props)
    return {"nodes": len(graph["vertices"]), "edges": len(graph["edges"]), "allow_frame_calls": matches}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--joern-home", required=True, type=Path, help="Directory containing joern-parse / joern-parse.bat")
    parser.add_argument("--cmake", default="cmake")
    parser.add_argument("--generator", default="Ninja")
    args = parser.parse_args()
    home = args.joern_home.resolve()
    suffix = ".bat" if os.name == "nt" else ""
    launchers = {name: home / (name + suffix) for name in ["joern-parse", "joern-export", "joern"]}
    for path in launchers.values():
        if not path.is_file():
            parser.error(f"Missing launcher: {path}. Point --joern-home to the extracted joern-cli directory.")
    if not shutil.which(args.cmake) and not Path(args.cmake).is_file():
        parser.error("CMake not found; use --cmake with the full executable path.")
    if not shutil.which("java"):
        parser.error("Java not found on PATH. Joern 4.0.666 was tested with JDK 21.")
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    output = ROOT / "results" / stamp
    output.mkdir(parents=True)
    records = []

    def run(name, command):
        command = [str(part) for part in command]
        print(f"[{name}] {subprocess.list2cmdline(command)}", flush=True)
        start = time.monotonic()
        log = output / (name + ".log")
        with log.open("w", encoding="utf-8") as stream:
            result = subprocess.run(command, cwd=output, stdout=stream, stderr=subprocess.STDOUT)
        record = {"stage": name, "command": command, "exit_code": result.returncode, "seconds": round(time.monotonic() - start, 3), "log": str(log)}
        records.append(record)
        (output / "commands.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
        if result.returncode:
            raise RuntimeError(f"{name} failed ({result.returncode}). Read {log}")

    try:
        run("java-version", ["java", "-version"])
        run("cmake-version", [args.cmake, "--version"])
        comparisons = {}
        for fixture in ["sample", "sample-explicit"]:
            source = ROOT / fixture
            build = output / (fixture + "-build")
            run(fixture + "-configure", [args.cmake, "-S", source, "-B", build, "-G", args.generator, "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON", "-DCMAKE_BUILD_TYPE=Debug"])
            run(fixture + "-build", [args.cmake, "--build", build, "--config", "Debug", "--parallel", "2"])
            executables = [build / "pipeline", build / "pipeline.exe", build / "Debug/pipeline.exe", build / "Debug/pipeline"]
            executable = next((path for path in executables if path.is_file()), None)
            if executable is None:
                raise RuntimeError(f"Built pipeline executable not found in {build}")
            run(fixture + "-run", [executable])
            compdb = build / "compile_commands.json"
            if not compdb.is_file():
                raise RuntimeError("No compile_commands.json. Select Ninja or Unix Makefiles with a working C++ toolchain.")
            cpg = output / (fixture + ".cpg.bin")
            run(fixture + "-parse", [launchers["joern-parse"], source, "--language", "c", "--output", cpg, "--frontend-args", "--compilation-database", compdb])
            exported = output / (fixture + "-graph")
            run(fixture + "-export", [launchers["joern-export"], cpg, "--repr", "all", "--format", "graphson", "--out", exported])
            query = output / (fixture + "-query.json")
            run(fixture + "-query", [launchers["joern"], "--script", ROOT / "inspect.sc", "--param", f"cpgFile={cpg}", "--param", f"output={query}"])
            comparisons[fixture] = inspect_graph(exported / "export.json")
            comparisons[fixture]["query_calls"] = json.loads(query.read_text(encoding="utf-8"))["allowFrameCalls"]
        covered = all(value["allow_frame_calls"] and value["query_calls"] for value in comparisons.values())
        report = {"status": "semantic_check_passed" if covered else "semantic_gap_detected", "fixtures": comparisons, "note": "Both fixtures should expose the same cross-component business call. Export success alone is insufficient. This is a small reproduction, not a complete C++ conformance benchmark."}
        (output / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(json.dumps(report, indent=2))
        print(f"Results: {output}")
        return 0 if covered else 2
    except Exception as error:
        print(str(error), file=sys.stderr)
        print(f"Partial logs retained: {output}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
