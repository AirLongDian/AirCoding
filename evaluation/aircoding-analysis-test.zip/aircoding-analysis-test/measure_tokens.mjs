import { readFileSync } from "node:fs";
import { getEncoding } from "js-tiktoken";

const files = process.argv.slice(2);
if (!files.length) {
  console.error("Usage: node measure_tokens.mjs path/to/export.json [more-files]");
  process.exit(1);
}
const encoding = getEncoding("o200k_base");
for (const path of files) {
  const text = readFileSync(path, "utf8");
  console.log(JSON.stringify({ path, encoding: "o200k_base", chars: text.length, tokens: encoding.encode(text).length }));
}
