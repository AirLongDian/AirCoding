# C++ 项目理解引擎云端可行性验证

日期：2026-10-28。所有夹具、工具及产物位于 AirCoding checkout 外；没有修改应用代码，没有启动 AirCoding。

## 当前结论

- clang-uml 0.6.3、scip-clang 0.4.1 与 CMake File API 已在 Debian 13 x86_64 云端实际执行。
- Joern 4.0.666 已实际完成解析、全图导出和 CPGQL 脚本查询；发现可复现的特定 C++ 写法覆盖缺口。
- Understand 未实测。机器上未找到可执行文件、Python 绑定或相关已注入配置名称；厂商下载与文档域名请求被代理 403 拒绝。用户说明单份授权不能转交。不能把这项外部阻塞记为通过或软件不支持 Linux。
- Understand 本地正版对照包为 understand-local-eval.zip，脚本尚待真实 Understand 环境执行。没有使用破解软件。

## 固定夹具与行为检查

sample 为 5 个 C++ 编译单元、5 个头文件。Capture、Decoder、UdpSender 与 Frame 用于结构验证；business::allow_frame 故意被 Decoder 调用，用于验证跨层引用。UdpSender 不执行真实 UDP 发送，组件不做真实编解码。

两个样例经 CMake 配置、GNU C++ 14.2 编译后均退出 0。sample-explicit 只将 Decoder 的初始化列表返回改成显式中间变量与成员赋值，功能结果相同。

## 混合工具实测

- clang-uml 类图导出 4 个元素、3 条关系；include 图导出 10 个元素、11 条关系。
- SCIP 索引 5 个编译单元，报告 0 个 errored TU；索引含 10 个文档、87 个 occurrence。
- 本地 inspect_index.py 遍历索引的定义与引用，得到 23 条跨文件引用边；本夹具中没有未找到索引内定义的非 local 引用。此结果不是所有真实项目均无缺口的保证。
- 精确定位 decoder.cpp 到 policy.cpp 的 business::allow_frame 引用，保留源码范围。
- CMake File API 返回 capture、decoder、sender、policy、pipeline 5 个 target，确认 decoder 对 policy 的工程依赖。
- scip-clang 对 workspace 外层 .git 路径打印根目录警告；输出 metadata.project_root 已核实为样例目录，跨文件预期关系检查通过。真实仓库测试仍需排除此类根目录歧义。

## Joern 实测与具体覆盖缺口

官方 Linux x86_64 发布包下载后对照官方 .sha512 校验通过，使用环境已有 JDK 21。

原始写法：

```cpp
return {business::allow_frame(input.value) ? input.value * 2 : 0};
```

原始样例解析退出 0，用时约 2.806 秒（单次小样例，不作规模性能结论）。导出 257 个节点、1118 条边，包括 AST、CFG、REF、CALL、REACHING_DEF 等。Decoder 的 METHOD CODE 保留源码，但 CALL 节点和 CPGQL `cpg.call.name("allow_frame")` 均没有该业务调用。

等价改写：

```cpp
const bool allowed = business::allow_frame(input.value);
Frame output;
output.value = allowed ? input.value * 2 : 0;
return output;
```

改写后导出 301 个节点、1455 条边，存在 NAME=allow_frame、METHOD_FULL_NAME=business.allow_frame:bool(int) 的 CALL 节点。

结论仅限该版本、该前端及这两个夹具：成功解析和图丰富不代表关键关系完整。未穷尽所有前端选项，也没有证明所有初始化列表调用都会丢失。不得为适配工具而要求业务代码改写。

## 输出 token 测量

使用 js-tiktoken 1.0.21 的 o200k_base。不是当前助手模型的精确计费 tokenizer，也未包含提示词、工具描述或模型回复。

| 数据 | token |
|---|---:|
| `diagrams/structure.json` | 947 |
| `diagrams/dependencies.json` | 644 |
| `global-references.json` | 5,188 |
| `global-references-compact.json` | 1,319 |
| `joern/graphson/export.json` | 325,214 |
| `joern/graphson/normalized.json` | 42,700 |
| `joern/graphson-explicit/export.json` | 406,296 |
| `joern/graphson-explicit/normalized.json` | 53,761 |
| 全部夹具源码（含文件名） | 298 |

这些输出覆盖范围不同：Joern 全图额外包含控制流、数据流等；不能把总 token 的差异直接解释为引擎优劣。原始 GraphSON 中还有大量类型包装。

global-references-compact.json 通过文件/符号字典及数组列定义保留该 23 条跨文件边的引用证据，避免重复字段和字符串。不能把该结果等同于对原始 SCIP 全部内容的无损压缩。

小样例源码只有 298 token，图和索引输出均比源码大，说明极小任务应直接读代码。大项目应将完整图保留外部，按问题返回全局依赖视图、受影响邻域和源码证据；不能每轮注入原始图。

## 可复现入口

- inspect_index.py：解析 index.scip 并核对预期结构、引用和 CMake target。
- joern/inspect.sc：运行 CPGQL 查询。
- joern/graphson/export.json、joern/graphson-explicit/export.json：两种写法的原始全图。
- joern/comparison.json：图计数与业务调用节点对照。
- token-measurements.json：token 计数与口径。
- UNDERSTAND-LOCAL.md、understand-local-eval.zip：本地正版验证说明和夹具。

## 未覆盖范围

未验证真实视频系统、Qt、复杂模板/宏、虚调用完备性、大型项目、增量更新与真实 LLM 任务 token 消耗。没有据此最终替换项目选型；待 Understand 本地结果与代表性工程验证后决定。
