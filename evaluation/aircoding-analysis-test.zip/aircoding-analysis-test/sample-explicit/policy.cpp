#include "policy.hpp"
namespace business { bool allow_frame(int value) { return value > 0; } }
