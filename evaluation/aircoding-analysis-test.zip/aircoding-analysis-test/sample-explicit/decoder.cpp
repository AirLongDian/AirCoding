#include "decoder.hpp"
#include "policy.hpp"
namespace media { Frame Decoder::decode(Frame input) const { const bool allowed = business::allow_frame(input.value); Frame output; output.value = allowed ? input.value * 2 : 0; return output; } }
