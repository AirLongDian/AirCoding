#pragma once
#include "frame.hpp"
namespace media { class Capture { public: Frame next() const; }; }
