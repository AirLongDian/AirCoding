#pragma once
#include "frame.hpp"
namespace media { class Decoder { public: Frame decode(Frame input) const; }; }
