#include "capture.hpp"
namespace media { Frame Capture::next() const { return {21}; } }
