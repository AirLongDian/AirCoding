#pragma once
namespace media { struct Frame { int value; }; }
