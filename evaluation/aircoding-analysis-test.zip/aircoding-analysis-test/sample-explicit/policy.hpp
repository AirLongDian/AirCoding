#pragma once
namespace business { bool allow_frame(int value); }
