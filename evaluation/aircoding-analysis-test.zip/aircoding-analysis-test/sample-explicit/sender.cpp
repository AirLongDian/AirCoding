#include "sender.hpp"
namespace media { int UdpSender::send(Frame input) const { return input.value; } }
