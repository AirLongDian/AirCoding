#pragma once
#include "frame.hpp"
namespace media { class UdpSender { public: int send(Frame input) const; }; }
