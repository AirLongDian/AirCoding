#include "capture.hpp"
#include "decoder.hpp"
#include "sender.hpp"
int main() { media::Capture c; media::Decoder d; media::UdpSender s; return s.send(d.decode(c.next())) == 42 ? 0 : 1; }
