#include "decoder.hpp"
#include "policy.hpp"
namespace media { Frame Decoder::decode(Frame input) const { return {business::allow_frame(input.value) ? input.value * 2 : 0}; } }
